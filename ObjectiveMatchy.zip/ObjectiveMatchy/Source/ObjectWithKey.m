//
//  ObjectWithKey.m
//  ObjectiveMatchy
//
//  Created by Matthias Hennemeyer on 05.07.09.
//  Copyright 2009 Matthias Hennemeyer. All rights reserved.
//

#import "ObjectWithKey.h"


@implementation ObjectWithKey

@end
