//
//  RespondToSelectorTest.h
//  ObjectiveMatchy
//
//  Created by Matthias Hennemeyer on 05.07.09.
//  Copyright 2009 ChocolateCode. All rights reserved.
//

#import "ObjectiveMatchy.h"
#import <SenTestingKit/SenTestingKit.h>


@interface RespondToSelectorTest : SenTestCase {
	NSObject * anObject;
}

@end
