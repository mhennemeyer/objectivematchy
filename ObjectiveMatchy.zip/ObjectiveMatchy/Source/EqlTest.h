//
//  EqlTest.h
//  ObjectiveMatchy
//
//  Created by Matthias Hennemeyer on 30.06.09.
//  Copyright 2009 Matthias Hennemeyer. All rights reserved.
//

#import "ObjectiveMatchy.h"
#import <SenTestingKit/SenTestingKit.h>


@interface EqlTest : SenTestCase {

}

@end
